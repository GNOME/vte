/* $Id: patchlev.h,v 1.18 2001/11/30 21:50:35 tom Exp $ */
#define PATCHLEVEL 7
#define PATCH_DATE 20011130
