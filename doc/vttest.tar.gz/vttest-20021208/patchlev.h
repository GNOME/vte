/* $Id: patchlev.h,v 1.20 2002/12/08 22:56:17 tom Exp $ */
#define PATCHLEVEL 7
#define PATCH_DATE 20021208
